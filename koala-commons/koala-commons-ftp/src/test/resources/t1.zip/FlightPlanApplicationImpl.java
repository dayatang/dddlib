package com.csair.opws.application.external.impl.flightinfo;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Named;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.transaction.annotation.Transactional;
import com.csair.opws.application.external.flightinfo.FlightPlanApplication;
import com.csair.opws.core.domain.external.ArpChnV;
import com.csair.opws.core.domain.external.Schedule;
import com.csair.opws.infra.util.MethodUtil;
import com.csair.opws.infra.vo.ArpChnVVO;
import com.csair.opws.infra.vo.FlightPlanInfoVO;
import com.csair.opws.infra.vo.FlightPlanVO;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import org.openkoala.koala.util.SpringEJBIntercepter;

@Named
@Transactional("secondTransactionManager")
@Interceptors(value = org.openkoala.koala.util.SpringEJBIntercepter.class)
@Stateless(name = "FlightPlanApplication")
public class FlightPlanApplicationImpl implements FlightPlanApplication {

    @Override
    public List<FlightPlanInfoVO> findByFltNum(FlightPlanVO flightPlanVO) {
        List<FlightPlanInfoVO> result = new ArrayList<FlightPlanInfoVO>();
        try {
            result = Schedule.findFltPlan(flightPlanVO);
            for (FlightPlanInfoVO fpvo : result) {
                String depDt = MethodUtil.convertminToDDHHmm(flightPlanVO.getFltDt(), fpvo.getDepDt());
                fpvo.setDepDt(depDt);
                String arvDt = MethodUtil.convertminToDDHHmm(flightPlanVO.getFltDt(), fpvo.getArvDt());
                fpvo.setArvDt(arvDt);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public List<String> getSearch(String arp) {
        ArrayList<String> result = new ArrayList<String>();
        List<ArpChnV> searchList = null;
        try {
            searchList = ArpChnV.getSearch(arp);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (ArpChnV acv : searchList) {
            byte[] b;
            String cityName = "";
            try {
                b = acv.getCityName().getBytes("ISO-8859-1");
                cityName = new String(b, "GBK");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            if (MethodUtil.stringIsNotEmpty(cityName)) {
                result.add(cityName);
            }
        }
        return result;
    }

    @Override
    public Map<String, String> findAllArpChnV() {
        List<ArpChnVVO> result = new ArrayList<ArpChnVVO>();
        Map<String, String> codeMap = new HashMap<String, String>();
        List<ArpChnV> all = ArpChnV.findAll(ArpChnV.class);
        for (ArpChnV acv : all) {
            ArpChnVVO vo = new ArpChnVVO();
            try {
                BeanUtils.copyProperties(vo, acv);
            } catch (Exception e) {
                e.printStackTrace();
            }
            result.add(vo);
        }
        for (ArpChnVVO vo : result) {
            byte[] b;
            String cityName = "";
            try {
                b = vo.getCityName().getBytes("ISO-8859-1");
                cityName = new String(b, "GBK");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            codeMap.put(cityName, vo.getCity());
        }
        return codeMap;
    }

    @Override
    public List<FlightPlanInfoVO> fltPlanDetails(FlightPlanVO fpvo) {
        List<FlightPlanInfoVO> result = null;
        try {
            result = Schedule.findFltPlan(fpvo);
        } catch (Exception e) {
            return result;
        }
        return result;
    }
}
